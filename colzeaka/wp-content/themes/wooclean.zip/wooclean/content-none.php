<?php
/**
 *
 * The template part for displaying a message that posts cannot be found.
 *
 */
?>

<div class="not-fount">
	<h1> <?php esc_html_e( 'Nothing found!', 'xclean' ); ?> </h1>
</div><!-- End .not-found -->