<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

 /**
 *
 * Initial widgets in this file.
 *
 */

get_template_part( 'framework/widgets/social-widget' );
?>